import java.util.Scanner;
public class Examen15122022{
    public static final int CARTAS_MAZO = 40; // Número de cartas del mazo
    public static final int MAX_CARTAS_EN_JUGADA = 8; //Máximo número de cartas que puede tener el jugador o la banca

    /** muestraBienvenida
     *  Muestra por pantalla un mensaje de bienvenida del juego
     */
    public static void muestraBienvenida(){
        System.out.println("********************** 7 Y MEDIA **********************");
        System.out.println("*            Un juego divertido y adictivo            *");
        System.out.println("*******************************************************");
    }

    /** baraja
     * Recibe una array de 40 elementos y debe rellenarlo con valores
     * aleatorios entre 0 y 39 ambos inclusive. No se pueden repetir 
     * los valores en el array de manera que estén los 40 diferentes
     * valores en el array
     * @param cartas array de enteros que contendrán las cartas
     */

    /** inicializaCartas
     *  Recibe un array y almacena un -1 en cada posición
     * @param array Array de enteros
     */

    /** pideApuesta
     * Debe solicitar la cantidad de dinero que se quiere apostar
     * y debe controlar que se introduce una cantidad 
     * igual o inferior de la del monedero y que sea mayor que  0
     * @param sc Scanner para leer los datos
     * @param monedero  Cantidad en el monedero
     * @return Cantidad de dinero que se quiere apostar
     */

    /** sacaUnaCarta
     * Devuelve el valor del array (mazo) en la posición dada y 
     * almacena un -1 en su lugar para indicar que la carta ya no se 
     * encuentra en el mazo
     * @param mazo Array conteniendo las cartas del mazo
     * @param posicion  Posición de la carta que se quiere obtener
     * @return Devuelve el contenido del array en dicha posición
     */

    /** imprimeCartas
     * Imprime por pantalla las cartas contenidas en el array 
     * suministrado. Escribirá un título que indica de que jugador
     * se trata.
     * @param titulo Título para mostrar antes de imprimir las cartas
     * @param cartas Array conteniendo las cartas a mostrar
     * @param numerosYFiguras Array conteniendo los textos de cada
     * una de las cartas posibles (Uno, Dos, Tres, …,Siete, Sota, 
     * Caballo, Rey)
     * @param palos Array conteniendo los nombres de los cuatro
     * palos (Oros, Copas, Espadas, Bastos)
     */

    /** sumaCartas
     * Suma la puntuación de las cartas contenidas en el array
     * teniendo en cuenta que las figuras puntúan medio punto y el 
     * resto de cartas el valor de la carta
     * @param cartas Array conteniendo las cartas
     * @return Devuelve la puntuación (puede contener decimales)
     */

    /** esSieteYMedia
     * Devuelve si la puntuación de las cartas en el array
     * suministrado es 7 y media
     * @param cartas Array conteniendo las cartas
     * @return Devuelve true si la puntuación es 7 y media y false
     * en caso contrario
     */

    /** puedeSeguirJugando
     * Con las cartas actuales del array suministrado devuelve si es
     * posible seguir jugando o no
     * @param cartas Array conteniendo las cartas
     * @return Devuelve true si se puede seguir jugando y false en 
     * caso contrario
     */

    /** quieresPlantarte
     * Devuelve si el jugador quiere plantarse o no. Tendrá que pedir
     * a través de un menú si quiere plantarse o seguir jugando
     * @param sc Scanner para poder solicitar datos por teclado
     * @return Devuelve true si se quiere plantar y false en caso
     * contrario
     */

    /** quieresSeguirJugando
     * Devuelve si el jugador quiere seguir jugando o no. Tendrá que
     * pedir a través de un menú si quiere seguir jugando o por el
     * contrario quiere salir del juego.
     * @param sc Scanner para poder solicitar datos por teclado
     * @return Devuelve true si quiere seguir jugando y false en caso
     * contrario
     */





    public static void main(String[] args){
        final int SIN_GANADOR = 0;
        final int GANA_JUGADOR = 1; // Gana el jugador
        final int GANA_BANCA = 2; // Gana la banca
        final int MONEDERO_JUGADOR = 1000; //importe inicial del monedero
        Scanner sc = new Scanner(System.in);
        String[] numerosYFiguras = {"Uno", "Dos", "Tres", "Cuatro", "Cinco", "Seis", "Siete", "Sota", "Caballo", "Rey"};
        String[] palos = {"Oros", "Copas", "Espadas", "Bastos"};
        int[] mazo = new int[CARTAS_MAZO]; // El mazo con las cartas que contiene valores int indicando la carta correspondiente
                                           // Si una carta no está se debe almacenar un -1 
                                           // 0 -> 1 de Oros
                                           // 1 -> 2 de Oros
                                           //...
                                           // 9 -> Rey de Oros
                                           // 10 -> 1 de Copas
                                           //...
                                           // 19 -> Rey de Copas
                                           // 20 -> 1 de Espadas
                                           //...
                                           // 29 -> Rey de Espadas
                                           // 30 -> 1 de Bastos
                                           //...
                                           // 39 -> Rey de Bastos
        int[] cartasJugador = new int[MAX_CARTAS_EN_JUGADA]; // Cartas del jugador
                                                             // Como máximo podrá tener 8 cartas 
                                                             // Se deben inicializar a -1 todas las cartas
                                                             // -1 indica que no hay carta
                                                             //p.ej.
                                                             //1, 9, 29, 17, -1, -1, -1, -1
                                                             //2 de Oros, Rey de Oros, Rey de Espadas, Sota de Copas, Sin carta, Sin Carta, Sin Carta
        int[] cartasBanca = new int[MAX_CARTAS_EN_JUGADA];   // Cartas de la banca
                                                             // Como máximo podrá tener 8 cartas 
                                                             // Se deben inicializar a -1 todas las cartas
                                                             // -1 indica que no hay carta   
                                                             //1, 9, 29, 17, -1, -1, -1, -1
                                                             //2 de Oros, Rey de Oros, Rey de Espadas, Sota de Copas, Sin carta, Sin Carta, Sin Carta
        int monedero = MONEDERO_JUGADOR;  //Este es el monedero del jugador con la cantidad actual de dinero que tiene
        boolean finJuego = false;  
        muestraBienvenida();
        do {
            baraja(mazo); //Se rellena el array de cartas del mazo con posiciones aleatorias de 0 a 39 sin repetir las cartas.
            inicializaCartas(cartasJugador); //Se inicializa el array de cartas del jugador a -1
            inicializaCartas(cartasBanca); //Se inicializa el array de cartas de la banca a -1
            int numCartasJugador = 0; //Indica el número de cartas que tiene el jugador
                                      //En el array de cartas del jugador las n primeras posiciones del array contendrán la
                                      //carta asignada en cada momento
                                      
            int numCartasBanca = 0;   //Indica el número de cartas que tiene la banca
                                      //En el array de cartas de la banca las n primeras posiciones del array contendrán la
                                      //carta asignada en cada momento
            int ganador = SIN_GANADOR; //Se indica que no hay ganador
            int apuesta = pideApuesta(sc, monedero); //Se le pide al jugador la apuesta a realizar
            boolean finPartidaJugador = false;
            do {
                /* TIENES QUE IMPLEMENTAR EL BUCLE DEL JUGADOR */
            } while (!finPartidaJugador);
            if(ganador == SIN_GANADOR){
                do {
                    /* TIENES QUE IMPLEMENTAR EL BUCLE DEL JUEGO DE LA BANCA */
                } while (/* CONDICIÓN DEL BUCLE DE LA BANCA */);
                imprimeCartas("BANCA", cartasBanca, numerosYFiguras, palos);
                ganador = sumaCartas(cartasBanca)<=7.5?GANA_BANCA:GANA_JUGADOR;
            }
            switch(ganador){
                case GANA_JUGADOR:
                    monedero += apuesta;
                    System.out.printf("Enhorabuena has ganado %d euros. Ahora tienes %d\n", apuesta, monedero);
                break;
                case GANA_BANCA:
                    monedero -= apuesta;
                    System.out.printf("La banca gana %d euros. Ahora tienes %d\n", apuesta, monedero);
                break;
            }
            if(monedero>0){
                if(!quieresSeguirJugando(sc))
                    finJuego = true;
            }
            else{
                System.out.print("Estás en bancarrota.\nGracias por jugar.\nFin del Juego");
                finJuego = true;
            }
        }while(!finJuego);
    }
}